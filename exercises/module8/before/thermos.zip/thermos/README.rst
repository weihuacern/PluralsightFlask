Thermos: a Flask Demo Project
=============================

Thermos is a simple social bookmarking site. It's a Flask project used as a
demo for the /Flask Fundamentals/ course on `Pluralsight <http://pluralsight.com>`_.

Author: `Reindert-Jan Ekker <http://www.rjekker.nl>`_.
